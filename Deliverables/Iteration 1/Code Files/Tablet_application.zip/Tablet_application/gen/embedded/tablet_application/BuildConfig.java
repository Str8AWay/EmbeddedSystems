/** Automatically generated file. DO NOT MODIFY */
package embedded.tablet_application;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}