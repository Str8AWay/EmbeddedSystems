/** Automatically generated file. DO NOT MODIFY */
package embedded.phone_application;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}